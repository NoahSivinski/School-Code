package cs1302.game;

/**
 * Driver class for the Minesweeper game project.
 */
public class MinesweeperDriver {
    public static void main(String[] args) {
        if (args[0].equals("--seed")) {
            MinesweeperGame x = new MinesweeperGame(args[1]);
            x.play();
        } else if (args[0].equals("--gen")) {
            System.out.println("Seedfile generation not supported.");
            System.exit(2);
        } else {
            System.out.println("Unable to interpret supplied command-line arguments.");
            System.exit(1);
        } //else
    } //main
} //MinesweeperDriver
