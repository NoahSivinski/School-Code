/*
 * Stat.java
 * Author:  [Anastasia Antoine] 
 * Submission Date:  [4/16/2021]
 *
 * Purpose: This program will compute the minimum, maximum, average
 * and mode by putting in the data. 
 *
 * Statement of Academic Honesty:
 *
 * The following code represents my own work. I have neither
 * received nor given inappropriate assistance. I have not copied
 * or modified code from any source other than the course webpage
 * or the course textbook. I recognize that any unauthorized
 * assistance or plagiarism will be handled in accordance with
 * the University of Georgia's Academic Honesty Policy and the
 * policies of this course. I recognize that my work is based
 * on an assignment created by the Department of Computer
 * Science at the University of Georgia. Any publishing 
 * or posting of source code for this assignment is strictly
 * prohibited unless you have written consent from the Department
 * of Computer Science at the University of Georgia.  
 */
public class Stat {

	double[] data; 
		
	
	public Stat() {
		this.data = new double[0];
	}
	
	public Stat (double[] d) {
		double[] newList = new double[0];
		if (d != null) {
			newList = new double[d.length];
			
			for(int i = 0; i < d.length; i++) {
				newList[i] = d[i];
			}
		}
		this.data = newList; 
	}
	public Stat (float[] f) {
		double[] newList = new double[0];
		if (f != null) {
			newList = new double[f.length];
			
			for(int i = 0; i < f.length; i++) {
				newList[i] = f[i];
			}
		}
		
		this.data = newList; 
	
	}
	public Stat (int[] i) {
		double[] newList = new double[0];
		if (i != null) {
			newList = new double[i.length];
			
			for(int j = 0; j < i.length; j++) {
				newList[j] = i[j];
			}
		}
		this.data = newList; 
	}
	public Stat (long[] lo) {
		double[] newList = new double[0];
		if (lo != null) {
			newList = new double[lo.length];
			
			for(int i = 0; i < lo.length; i++) {
				newList[i] = lo[i];
			}
		}
		this.data = newList; 
	}
	
	public void setData(float[] f) {
		double[] newList = new double[0];
		if (f != null) {
			newList = new double[f.length];
			
			for(int i = 0; i < f.length; i++) {
				newList[i] = f[i];
			}
		}
		
		this.data = newList; 
	}
	
	public void setData(double[] d) {
		double[] newList = new double[0];
		if (d != null) {
			newList = new double[d.length];
			
			for(int i = 0; i < d.length; i++) {
				newList[i] = d[i];
			}
		}
		this.data = newList; 
	}
	
	public void setData(int[] i) {
		double[] newList = new double[0];
		if (i != null) {
			newList = new double[i.length];
			
			for(int j = 0; j < i.length; j++) {
				newList[j] = i[j];
			}
		}
		this.data = newList; 
	}
	
	public void setData(long[] lo) {
		double[] newList = new double[0];
		if (lo != null) {
			newList = new double[lo.length];
			
			for(int i = 0; i < lo.length; i++) {
				newList[i] = lo[i];
			}
		}
		this.data = newList; 
	}
	
	public double[] getData() {
		double[] newList = new double[data.length];
		for(int i = 0; i < data.length; i++) {
			newList[i] = data[i];
		}
		return newList; 	
	}
	
	public boolean equals(Stat s) {
		double sdata[] = s.getData();
		if (data.length != sdata.length) {
			return false;
		}
		for (int i = 0; i < data.length; i++) {
			if (data[i] != sdata[i]) {
				return false; 
			}
		}
		return true; 
	}
	
	public void reset() {
		double reset[] = new double[this.data.length];
		this.data = reset; 
	}
	
	public void append(int[] i) {
		if (i != null) {
			double[] array = new double[this.data.length + i.length];
			for (int j = 0; j < array.length; j++) {
				if (j < data.length) {
					array[j] = this.data[j];
				}
				else {
					array[j] = i[j - data.length];
				}
				
			}
		
			this.data = array; 
		}
	}
	
	
    public void append(float[] f) {
    	if (f != null) {
    		double[] array = new double[this.data.length + f.length];
    		for (int i = 0; i < array.length; i++) {
    			if (i < data.length) {
					array[i] = this.data[i];
				}
				else {
					array[i] = f[i - data.length];
				}
    		}
    		
    		this.data = array; 
    	}
	}
    
    public void append(long[] lo) {
    	if (lo != null) {
    		double[] array = new double[this.data.length + lo.length]; 
    		for (int i = 0; i < array.length; i++) {
    			if (i < data.length) {
					array[i] = this.data[i];
				}
				else {
					array[i] = lo[i - data.length];
				}
    		}
    		
    		this.data = array; 
    	}

	}
    
    public void append(double[] d) {
    	if (d != null) {
    		double[] array = new double[this.data.length + d.length]; 
    		for (int i = 0; i < array.length; i++) {
    			if (i < data.length) {
					array[i] = this.data[i];
				}
				else {
					array[i] = d[i - data.length];
				}
    		}
    		
    		this.data = array; 
    	}
	
	}
    
    public boolean isEmpty() {
    	return data.length == 0;    
    }

	public String toString() {
		if (isEmpty()) {
		    return "[]";
		}
	
	    String listData = "["; 
		for (int i = 0; i < data.length; i++) {
			listData += data[i];
			if (i == data.length - 1) {
				listData += "]";
			}
			else {
				listData += ", "; 
			}
		}
		return listData; 
		
		
	}
	
	public double min() {
		if (!isEmpty()) {
			double min = data[0]; 
			for (int i = 0; i < data.length; i++) {
				if (min > data[i]) {
					min = data[i]; 
				}
				else {
					return min;
				}
			}
		}
		return Double.NaN; 
	}
	
	public double max() {
		if (!isEmpty()) {
			double max = data[0]; 
			for(int i = 1; i < data.length; i++) {
				if(data[i] > max) {
					max = data[i];
				}
			}
			return max;
		}
		return Double.NaN; 
	}
	
	public double average () {
		double sum = 0.0;
		for(int i = 0; i< data.length; i++) {
			sum += data[i];
		}
		return sum / data.length;
	}
	
	public double mode() {
		double maxNumber = 0.0;
		int maxNumberCount = 0; 
		for(int i = 0; i < data.length; i++) {
			int numberCount = 0;
			for(int k =0; k < data.length; k++) {
				if(data[i]== data[k]) {
					numberCount++;
				}
			}
			if(numberCount > maxNumberCount) {
				maxNumberCount = numberCount;
				maxNumber = data[i];
			}
		}
		if(maxNumberCount > 1) {
			return maxNumber;
		}
		else {
			return Double.NaN;
		}
	}
	
	public int occursNumberOfTimes(double value) {
		int count = 0;
		for (int i = 0; i < this.data.length; i++) {
			if (this.data[i] == value) {
				count++;
			}
		}
		return count; 
	}
	
	public double variance() {
		double average = 0; 
		for (int i = 0; i < this.data.length; i++) {
			average = average + this.data[i];
		}
		average = average / this.data.length;
		double var = 0; 
		for(int i = 0; i < this.data.length; i++) {
			var = var + Math.pow(this.data[i] - average, 2);
		}
		return var / this.data.length;
	}
	
	public double standardDeviation() {
		double variance = variance();
		return Math.sqrt(variance);
	}
			

	

}