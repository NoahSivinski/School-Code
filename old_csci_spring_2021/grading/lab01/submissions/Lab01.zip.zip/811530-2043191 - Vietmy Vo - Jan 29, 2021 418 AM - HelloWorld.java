/**
 * 
 */

/**
 * @author Vietmy Vo
 *
 */
public class HelloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");

	}

}
