/*
Zachary Krausman
Soheyla Amirian - Pranav Pandey (Lab 26986)
Lab 1 - Introduction to Eclipse
*/
public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!");

	}

}
