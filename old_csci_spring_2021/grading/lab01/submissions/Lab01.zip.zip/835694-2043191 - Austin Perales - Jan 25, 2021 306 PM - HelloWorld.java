/**
 * 
 * @author Austin Perales
 *
 */
public class HelloWorld {

	public static void main(String[] args) {
		
		/**
		 *  @param args
		 */
		System.out.println("Hello World!");
		
	}

}