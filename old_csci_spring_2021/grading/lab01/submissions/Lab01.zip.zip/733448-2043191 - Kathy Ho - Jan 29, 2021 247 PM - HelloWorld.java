/**
 * @author Kathy Ho
 *Lab 1 Section 27832
 */
public class HelloWorld {
	public static void main (String[]args) {
		
		System.out.println("Hello World!");
	}
}
