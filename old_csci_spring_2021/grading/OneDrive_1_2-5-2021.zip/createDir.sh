for i in $(seq -w 1 13); do
    mkdir lab$i;
    mkdir lab$i/submissions;
done

